var world = "World";
console.log("Hello " + world);
