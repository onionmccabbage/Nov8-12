import { Injectable } from '@angular/core';
import { User } from './user.model';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators'

@Injectable({
  providedIn: 'root'
})
export class UserService {
  users: User[];
  USERSURL = `http://localhost:3000/users` // constants are conventionaly ALL CAPS
  constructor(private http: HttpClient) { }

  // getUsers() {
  //   return this.users;
  // }
  getUsers(): Observable<User[]> {
    return this.http.get<User[]>(this.USERSURL)
      .pipe(
        catchError(this.handleError)
      )
  }

  // addUser(user: User) {
  //   const users = this.users;
  //   users.push(user);
  //   this.users = users;
  // }
  addUser(user): Observable<User> {
    return this.http.post<User>(this.USERSURL, user)
  }

  // here is a generic error handler for our service methods
  handleError(error:HttpErrorResponse){
    return throwError(error)
  }
}
