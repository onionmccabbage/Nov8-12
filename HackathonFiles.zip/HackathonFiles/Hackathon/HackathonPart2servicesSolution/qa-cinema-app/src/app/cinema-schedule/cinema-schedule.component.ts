import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cinema-schedule',
  templateUrl: './cinema-schedule.component.html',
  styleUrls: ['./cinema-schedule.component.css']
})
export class CinemaScheduleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
