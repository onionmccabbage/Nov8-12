import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class UsersService {

  constructor(private http:HttpClient) { }

  // methods of this service (things the service can do)
  getUsers(){
    let url = 'https://jsonplaceholder.typicode.com/users/1'
    this.http.get(url).subscribe(
      (data)=>{ // the response from the server
        console.log(`response :${data}`)
      })
  }
}
