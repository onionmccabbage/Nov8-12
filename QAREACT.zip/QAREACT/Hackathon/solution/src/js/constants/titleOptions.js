export const titleOptions = [
    { value: `Ms`, display: `Ms` },
    { value: `Miss`, display: `Miss` },
    { value: `Mrs`, display: `Mrs` },
    { value: `Mr`, display: `Mr` },
    { value: `Dr`, display: `Dr` },
];