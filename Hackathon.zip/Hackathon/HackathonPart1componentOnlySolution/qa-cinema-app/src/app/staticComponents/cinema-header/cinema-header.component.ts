import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cinema-header',
  templateUrl: './cinema-header.component.html',
  styleUrls: ['./cinema-header.component.css']
})
export class CinemaHeaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
