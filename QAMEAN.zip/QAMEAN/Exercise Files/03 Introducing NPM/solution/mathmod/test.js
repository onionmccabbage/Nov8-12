const mathmod = require('./mathmod.js');
let result1 = mathmod.add(2,7);
let result2 = mathmod.multiply(7,8);

console.log(result1,result2);