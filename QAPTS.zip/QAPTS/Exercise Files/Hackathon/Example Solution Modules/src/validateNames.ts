import { displayMessage, displayErrorBorder, removeMessage } from './validationDisplay';

export let firstNameValid: boolean = false;
export let lastNameValid: boolean = false;

export const nameValidation = (event: Event) => {
    const nameRegEx: RegExp = /^[a-zA-Z\'\-]+$/g;
    const nameInput: HTMLInputElement = (event.currentTarget as HTMLInputElement);
    const name: string = nameInput.value;
    const idCapFirst: string = (nameInput.id.slice(0, 1).toUpperCase()) + nameInput.id.slice(1);
    const msgName: HTMLElement = document.querySelector(`#msg${idCapFirst}`);
    let nameValid: boolean = false;

    if (name.length > 1 && name.length < 25) {
        if (!name.match(nameRegEx)) {
            displayMessage(msgName, "Only letters, hyphens and apostrophes are allowed");
            nameValid = false;
        } else {
            removeMessage(msgName);
            nameValid = true;
        }    
    } else {
        nameValid = false;
        displayMessage(msgName, "The name entered is either too short or too long.");
    }
    
    displayErrorBorder(nameValid, nameInput);

    if (nameInput.id.indexOf('last') !== -1) {
        lastNameValid = nameValid;
    } else if (nameInput.id.indexOf('first') !== -1) {
        firstNameValid = nameValid;
    } else {
      lastNameValid = false;
      firstNameValid = false;
  }
}