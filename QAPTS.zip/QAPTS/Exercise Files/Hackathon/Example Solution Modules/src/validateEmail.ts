import { displayMessage, displayErrorBorder, removeMessage } from './validationDisplay'; 

export let emailValid: boolean = false;

export const emailValidation = (): void => {
    const emailRegex: RegExp = /[^\s@]+@[^\s@]+\.[^\s@]+/;
    const email: string = document.forms[0]["email"].value;
    const emailInput: HTMLElement = document.querySelector("#email");
    const msgEmail: HTMLElement = document.querySelector("#msgEmail");
    if(!email.match(emailRegex)) {
      emailValid = false;
      removeMessage( msgEmail );
      displayMessage( msgEmail, "Email address not valid")
    }
    else{
      emailValid = true;
      removeMessage( msgEmail );
    }
    displayErrorBorder( emailValid, emailInput );
  }