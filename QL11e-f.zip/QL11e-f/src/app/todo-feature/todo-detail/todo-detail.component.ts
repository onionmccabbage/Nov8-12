import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { Todo } from '../todo.model';
import { TodoService } from '../todo.service';
import { ActivatedRoute, Router, ParamMap } from '@angular/router';
import { switchMap } from 'rxjs/operators';

@Component({
  selector: 'app-todo-detail',
  templateUrl: './todo-detail.component.html',
  styleUrls: ['./todo-detail.component.css']
})
export class TodoDetailComponent implements OnInit {
  // we need an observable
  todo$:Observable<Todo>
  constructor(private todoService:TodoService, 
              private route:ActivatedRoute,
              private router:Router) { }

  ngOnInit() {
    // when the component loads, 
    // we will grab the todo parameter from the route
    this.todo$ = this.route.paramMap.pipe(
      switchMap( (params:ParamMap)=>{
        return this.todoService.getTodo(params.get('id'))
      } )
    )
  }
  // we need a method to imperatively route 
  // to todo home component
  goToTodoHome(){
    this.router.navigate(['/todo'])
  }

}
