Create a new React Application using:

npx create-react-app qacinemasfrontend

Copy the contents of public into the public folder in the new application
Copy the contents of src into the src folder in the new application
