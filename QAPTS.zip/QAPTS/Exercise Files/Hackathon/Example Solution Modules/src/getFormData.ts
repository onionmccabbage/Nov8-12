import User from './user';

const getFormData = (): User => {
    let title: string = (document.querySelector("#title") as HTMLInputElement).value;
    let firstName: string = (document.querySelector("#firstName") as HTMLInputElement).value;
    let lastName: string = (document.querySelector("#lastName") as HTMLInputElement).value;
    let email: string = (document.querySelector("#email") as HTMLInputElement).value;
    let phoneNumber: string = (document.querySelector("#phoneNumber") as HTMLInputElement).value;
    let dob: string = (document.querySelector("#dob") as HTMLInputElement).value;
    let gender: string = (document.querySelector('input[name="genderRadios"]:checked') as HTMLInputElement).value;

    let newUser: User = new User(title, firstName, lastName, email, phoneNumber, dob, gender);
    return newUser;
}

export default getFormData;