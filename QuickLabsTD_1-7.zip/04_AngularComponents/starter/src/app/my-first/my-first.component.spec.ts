import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MyFirstComponent } from './my-first.component';
import { FormsModule } from '@angular/forms';
import { DebugElement } from '@angular/core';

describe('MyFirstComponent', () => {
  let component: MyFirstComponent;
  let fixture: ComponentFixture<MyFirstComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [MyFirstComponent],
      imports: [FormsModule]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MyFirstComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

});

describe('DOM Testing', () => {
  let fixture: ComponentFixture<MyFirstComponent>;
  let myFirstComponentDe: DebugElement;
  let myFirstComponentEl: HTMLElement;

  beforeEach(async () => {
    TestBed.configureTestingModule({
      declarations: [MyFirstComponentComponent],
      imports: [FormsModule]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MyFirstComponent);
    myFirstComponentDe = fixture.debugElement;
    myFirstComponentEl = myFirstComponentDe.nativeElement;
  })
})
