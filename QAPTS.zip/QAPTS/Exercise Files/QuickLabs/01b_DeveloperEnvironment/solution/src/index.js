var world = "World";
console.log("Hello " + world);
//# sourceMappingURL=index.js.map