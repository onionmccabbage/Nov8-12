import { AbstractControl, ValidatorFn, ValidationErrors } from '@angular/forms';

export function ageRangeValidator(min: number, max: number): ValidatorFn {
  return (control: AbstractControl): ValidationErrors => {
    if ((!control.value || isNaN(control.value)) || control.value < min || control.value > max) {
      return { 'ageRange': {value: control.value} };
    }
    return null;
  };
}
