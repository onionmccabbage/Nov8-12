import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { CinemaScheduleComponent } from './cinema-schedule.component';

describe('CinemaScheduleComponent', () => {
  let component: CinemaScheduleComponent;
  let fixture: ComponentFixture<CinemaScheduleComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ CinemaScheduleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CinemaScheduleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
