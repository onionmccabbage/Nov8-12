import { validateForm } from "./validateForm";

import User from './User';

const newUserUrl: string = `http://localhost:3000/users`;

export const submitForm = (event: Event): void => {
    event.preventDefault();
    let user: User|null = validateForm();
    if(user) {
        sendForm(user)
            .then(response => {
                response.ok ? alert(`Data submitted`) : alert(`There was a problem submitting the data`);
            });
    }
}

const sendForm = async (user: User) => {
    let userToSubmit: string = JSON.stringify(user);

    let response = await fetch(newUserUrl, {
        method: 'POST',
        mode: 'cors',
        headers: {
            "Content-Type": "application/json"
        },
        body: userToSubmit
    });
    return response;
}