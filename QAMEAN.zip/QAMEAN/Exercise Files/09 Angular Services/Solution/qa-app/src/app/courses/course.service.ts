import { Injectable } from '@angular/core';
import { Observable, Observer } from 'rxjs';
import { Course } from 'app/courses/course.model';

@Injectable()
export class CourseService {

  courses = [
    {
        "title": "Building JavaScript Applications Using NodeJS and the MEAN Stack",
        "code": "QANODEDEV",
        "delivery": "Classroom",
        "days": 3
    },
    {
        "title": "Developing MVC single-page web applications using AngularJS",
        "code": "QAANGULARJS",
        "delivery": "Classroom",
        "days": 2
    },
    {
        "title": "Developing Web Applications Using HTML5",
        "code": "QAWEBUI",
        "delivery": "Classroom",
        "days": 5
    },
    {
        "title": "Leveraging the Power of JQuery",
        "code": "QAJQUERY",
        "delivery": "Classroom",
        "days": 3
    },
    {
        "title": "Programming with JavaScript",
        "code": "QAJAVSC",
        "delivery": "Classroom",
        "days": 5
    },
    {
        "title": "Next Generation JavaScript: ECMAScript2015",
        "code": "QAES2015",
        "delivery": "Classroom",
        "days": 2
    },
    {
        "title": "Building Web Applications Using Angular",
        "code": "QAANGULAR",
        "delivery": "Classroom",
        "days": 3
    }
]

  constructor() { }

  getCourses(): Observable<Course[]> {
    return Observable.create((observer: Observer<Course[]>) => {
      setTimeout(()=>{
        observer.next(this.courses);
        observer.complete();
      },1500);
    })
  }

}
