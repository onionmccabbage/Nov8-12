import React from 'react';

const AnotherComponent = () => {
    return (
        <>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Laudantium, doloremque.</p>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptatum, quas.</p>
        </>
    )
}

export default AnotherComponent;
