import Validators from './Validators';

export default class User {
    constructor(
        private _title: string = ``, 
        private _firstName: string = ``, 
        private _lastName: string = ``, 
        private _email: string = ``, 
        private _phoneNumber: string = ``, 
        private _dob: string = ``, 
        private _gender: string = ``
      ) {}

    setTitle(title): void {
        this._title = title;
    }

    getTitle(): string {
        return this._title;
    }

    setFirstName(event): void {
        let { update, name } = Validators.validateName(event);
        if(update) {
            this._firstName = name;
        }
    }

    getFirstName(): string {
        return this._firstName;
    }

    setLastName(event): void {
        let { update, name } = Validators.validateName(event);
        if(update) {
            this._lastName = name;
        }
    }

    getLastName(): string {
        return this._lastName;
    }

    setEmail(event): void {
        let { update, email } = Validators.validateEmail(event);
        if(update) {
            this._email = email;
        }
    }

    getEmail(): string {
        return this._email;
    }

    setPhoneNumber(phoneNumber): void {
        this._phoneNumber = phoneNumber;
    }

    getPhoneNumber(): string {
        return this._phoneNumber;
    }

    setDob(dob): void {
        this._dob = dob;
    }

    getDob(): string {
        return this._dob;
    }

    setGender(gender): void {
        this._gender = gender;
    }

    getGender(): string {
        return this._gender;
    }
}