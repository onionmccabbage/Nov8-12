import ValidationStyles from "./ValidationStyles";

export default abstract class Validators {

    static readonly nameRegEx: RegExp = /^[a-zA-Z\'\-]+$/g;
    static readonly emailRegex: RegExp = /[^\s@]+@[^\s@]+\.[^\s@]+/;

    static validateName = (event: Event): {update, name} => {
        const nameInput: HTMLInputElement = (event.currentTarget as HTMLInputElement);
        const name: string = nameInput.value;
        const idCapFirst: string = (nameInput.id.slice(0, 1).toUpperCase()) + nameInput.id.slice(1);
        const msgName: HTMLElement = document.querySelector(`#msg${idCapFirst}`);
        let update: boolean = false;

        if (name.length > 1 && name.length < 25) {
            if (!name.match(Validators.nameRegEx)) {
                ValidationStyles.displayMessage(msgName, `Only letters, hyphens and apostrophes are allowed`);
                update = false;
            } else {
                ValidationStyles.removeMessage(msgName);
                update = true;
            }
        } else {
            update = false;
            ValidationStyles.displayMessage(msgName, `The name entered is either too short or too long.`);
        }
        ValidationStyles.displayErrorBorder(update, nameInput);

        return {update, name};
    }

    static validateEmail = (event: Event): {update, email} => {
        const email: string = (event.currentTarget as HTMLInputElement).value;
        const emailInput: HTMLElement = document.querySelector(`#email`);
        const msgEmail: HTMLElement = document.querySelector(`#msgEmail`);
        let update: boolean = false;

        if(!email.match(Validators.emailRegex)) {
          update = false;
          ValidationStyles.removeMessage( msgEmail );
          ValidationStyles.displayMessage( msgEmail, `Email address not valid`);
        }
        else{
          update = true;
          ValidationStyles.removeMessage( msgEmail );
        }
        
        ValidationStyles.displayErrorBorder( update, emailInput );

        return {update, email};
    }
}