import { Observable, of, fromEvent } from 'rxjs'

// of operator
let ofOperatorObservable: Observable<number> = of(1,2,3,4,5,6,7,8,9)
ofOperatorObservable.subscribe( (value:number)=>{
    console.log(`the 'of' operator emmited ${value}`)
} )

// fromEvent Operator
let fromEventButton:HTMLInputElement = document.querySelector(`#fromEvent`)
let fromEventOperatorObservable: Observable<Event> = 
                                    fromEvent(fromEventButton, 'click')
fromEventOperatorObservable.subscribe( (event:Event)=>{
    console.log(`The html button raised a ${event.type} event`)
} )