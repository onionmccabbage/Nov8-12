export const GETALLFILMS = `https://localhost/allFilms`;
export const GETOPENINGS = `https://localhost/openingTimes`;
export const GETSINGLEFILM = `https://localhost/singleFilm/`;
export const POSTSIGNUP = `https://localhost/signup`;