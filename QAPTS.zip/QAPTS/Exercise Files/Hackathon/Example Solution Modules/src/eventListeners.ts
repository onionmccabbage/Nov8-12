import { submitForm } from './submitForm';
import { nameValidation } from './validateNames';
import { emailValidation } from './validateEmail';

const activateEventListeners = (): void => {
    document.querySelector('#signUpForm').addEventListener('submit', submitForm);
    (document.querySelector('#firstName') as HTMLInputElement).addEventListener('change', nameValidation);
    (document.querySelector('#lastName')as HTMLInputElement).addEventListener('change', nameValidation);
    document.querySelector('#email').addEventListener('change', emailValidation);
}

export default activateEventListeners;
