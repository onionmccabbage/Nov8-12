import Form from './Form';

const form: Form = new Form();
form.activateEventListeners();