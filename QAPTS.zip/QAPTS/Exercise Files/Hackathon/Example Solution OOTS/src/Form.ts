import User from './User';

export default class Form {

    readonly newUserUrl: string = `http://localhost:3000/users`;
    private user: User;

    constructor() {
        this.user = new User();
    }

    getRemainingFormValues = (): void => {
        if (this.user.getFirstName() && this.user.getLastName() && this.user.getEmail()) {
            this.user.setTitle((document.querySelector("#title") as HTMLInputElement).value);
            this.user.setPhoneNumber((document.querySelector("#phoneNumber") as HTMLInputElement).value);
            this.user.setDob((document.querySelector("#dob") as HTMLInputElement).value);
            this.user.setGender((document.querySelector('input[name="genderRadios"]:checked') as HTMLInputElement).value);
        } else {
            alert("The form contains errors!");
        }
    }

    submitForm = (event: Event): void => {
        event.preventDefault();
        this.getRemainingFormValues();
        if (this.user) {
            this.sendForm()
                .then(response => {
                    response.ok ? alert(`Data submitted`) : alert(`There was a problem submitting the data`);
                });
        }
    };

    sendForm = async () => {
        
        let response = await fetch(this.newUserUrl, {
            method: 'POST',
            mode: 'cors',
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(this.user)
        });

        return response;
    }

    activateEventListeners = (): void => {
        document.querySelector('#signUpForm').addEventListener('submit', this.submitForm);
        document.querySelector('#firstName').addEventListener('change', this.user.setFirstName);
        document.querySelector('#lastName').addEventListener('change', this.user.setLastName);
        document.querySelector('#email').addEventListener('change', this.user.setEmail);
    }
}