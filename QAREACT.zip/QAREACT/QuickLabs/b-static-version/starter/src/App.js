import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap';
import 'popper.js';
import 'jquery';
import './Components/css/qa.css';

function App() {
  return (
    <div className="container">
      <div className="container">
        <h1>
          Other UIs to go here
        </h1>
      </div>
    </div>
  );
}

export default App;
