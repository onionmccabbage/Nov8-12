import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class CinemaService {
  // the json-server offers these API URLs:
  // http://localhost:3000/openingTimes
  // http://localhost:3000/films
  // http://localhost:3000/users

  serverURL = 'http://localhost:3000'
  scheduleAPI = 'openingTimes'
  filmsAPI    = 'films'
  usersAPI    = 'users'

  constructor(private http:HttpClient) { }

  // method to get the schedule
  getSchedule(){
    return this.http.get(`${this.serverURL}/${this.scheduleAPI}`)
  }

  // method to get whats on
  getWhatsOn(){
    return this.http.get(`${this.serverURL}/${this.filmsAPI}`)
  }
  // method to get users
  getUsers(){
    return this.http.get(`${this.serverURL}/${this.usersAPI}`)
  }

}
