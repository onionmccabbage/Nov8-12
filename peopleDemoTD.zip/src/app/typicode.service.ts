import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'

@Injectable({
  providedIn: 'root'
})
export class TypicodeService {

  constructor(private http:HttpClient) { }
  // methods of this service
  getAPI(cat:string, id:number){
    // here we make an Observable
    return this.http.get(`https://jsonplaceholder.typicode.com/${cat}/${id}`)
  }
}
