import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cinema-home',
  templateUrl: './cinema-home.component.html',
  styleUrls: ['./cinema-home.component.css']
})
export class CinemaHomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
