import { firstNameValid, lastNameValid } from './validateNames';
import { emailValid } from './validateEmail';
import getFormData from './getFormData';
import User from './User';

export const validateForm = (): User|null => {
    if ( firstNameValid && lastNameValid && emailValid ){
        let user: User = getFormData();
        return user;
    }
    else{
      alert("The form contains errors!");
    }
    return null;
}