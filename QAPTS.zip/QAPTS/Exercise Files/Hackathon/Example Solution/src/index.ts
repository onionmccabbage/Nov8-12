let firstNameValid: boolean = false;
let lastNameValid: boolean = false;
let emailValid: boolean = false;

const newUserUrl: string = `http://localhost:3000/users`;

type User = {};

const getFormData = (): User => {
    let title: string = (document.querySelector("#title") as HTMLInputElement).value;
    let firstName: string = (document.querySelector("#firstName") as HTMLInputElement).value;
    let lastName: string = (document.querySelector("#lastName") as HTMLInputElement).value;
    let email: string = (document.querySelector("#email") as HTMLInputElement).value;
    let phoneNumber: string = (document.querySelector("#phoneNumber") as HTMLInputElement).value;
    let dob: string = (document.querySelector("#dob") as HTMLInputElement).value;
    let gender: string = (document.querySelector('input[name="genderRadios"]:checked') as HTMLInputElement).value;

    let newUser: User = {title, firstName, lastName, email, phoneNumber, dob, gender};
    return newUser;
}

const validateForm = (): User|null => {
    if ( firstNameValid && lastNameValid && emailValid ){
        let user: User = getFormData();
        return user;
    }
    else{
      alert("The form contains errors!");
    }
    return null;
}

const sendForm = async (user: User) => {
    let userToSubmit: string = JSON.stringify(user);

    let response = await fetch(newUserUrl, {
        method: 'POST',
        mode: 'cors',
        headers: {
            "Content-Type": "application/json"
        },
        body: userToSubmit
    });
    return response;
}

const submitForm = (event: Event): void => {
    event.preventDefault();
    let user: User|null = validateForm();
    if(user) {
        sendForm(user)
            .then(response => {
                response.ok ? alert(`Data submitted`) : alert(`There was a problem submitting the data`);
            });
    }
}

const firstNameValidation = (): void => {
    console.log('Validating first name');
    const firstNameRegex: RegExp = /^[a-zA-Z]+$/;
    const firstName: string = document.forms[0]["firstName"].value;
    const firstNameInput: HTMLInputElement = document.querySelector("#firstName");
    const msgFirstName: HTMLElement = document.querySelector("#msgFirstName");
    if (firstName.length > 1 && firstName.length < 15) {
        if (!firstName.match(firstNameRegex)) {
            firstNameValid = false;
            displayMessage(msgFirstName, "Only lower and upper case letters are allowed");
        }
        else {
            firstNameValid = true;
            removeMessage(msgFirstName);
        }
    }
    else {
        firstNameValid = false;
        displayMessage(msgFirstName, "The First Name entered is either too short or too long.")
    }
    displayErrorBorder(firstNameValid, firstNameInput);
}

const lastNameValidation = (): void => {
    const lastNameRegex: RegExp = /^[a-zA-Z\'\-]+$/g;
    const lastName: string = document.forms[0]["lastName"].value;
    const lastNameInput: HTMLInputElement = document.querySelector("#lastName");
    const msgLastName: HTMLElement = document.querySelector("#msgLastName");
    if (lastName.length > 1 && lastName.length < 25) {
        if (!lastName.match(lastNameRegex)) {
            lastNameValid = false;
            displayMessage(msgLastName, "Only letters, hyphen and apostrohe are allowed.")
        }
        else {
            lastNameValid = true;
            removeMessage(msgLastName);
        }
    }
    else {
        lastNameValid = false;
        displayMessage(msgLastName, "The Last Name entered is either too short or too long.")
    }
    displayErrorBorder(lastNameValid, lastNameInput);
}

const emailValidation = (): void => {
    const emailRegex: RegExp = /[^\s@]+@[^\s@]+\.[^\s@]+/;
    const email: string = document.forms[0]["email"].value;
    const emailInput: HTMLInputElement = document.querySelector("#email");
    const msgEmail: HTMLElement = document.querySelector("#msgEmail");
    if (!email.match(emailRegex)) {
        emailValid = false;
        displayMessage(msgEmail, "Email address not valid")
    }
    else {
        emailValid = true;
        removeMessage(msgEmail);
    }
    displayErrorBorder(emailValid, emailInput);
}

const displayErrorBorder = (inputValid: boolean, element: HTMLElement): void => {
    if (!inputValid) {
        if (!element.classList.contains("invalid")) {
            element.classList.toggle("invalid");
        }
    }
    else {
        if (element.classList.contains("invalid")) {
            element.classList.toggle("invalid");
        }
    }
}

const displayMessage = (element: HTMLElement, message: string): void => {
    const msgcontent: HTMLElement = document.createElement("div");
    msgcontent.id = "msgcontent";
    element.appendChild(msgcontent);
    msgcontent.textContent = message;
}

const removeMessage = (element: HTMLElement): void => {
    if (element.childNodes.length > 0) {
        const noChildren: number = element.childNodes.length;
        for (let i = 0; i < noChildren; i++) {
            element.removeChild(element.firstChild);
        }
    }
}

//Event handlers
document.querySelector('#form').addEventListener('submit', submitForm);
document.querySelector('#firstName').addEventListener('change', firstNameValidation);
document.querySelector('#lastName').addEventListener('change', lastNameValidation);
document.querySelector('#email').addEventListener('change', emailValidation);