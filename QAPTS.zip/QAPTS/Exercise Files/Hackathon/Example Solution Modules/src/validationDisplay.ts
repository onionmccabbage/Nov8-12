export const displayErrorBorder = (inputValid: boolean, element: HTMLElement): void => {
  if (!inputValid) {
    if (!element.classList.contains("invalid")) {
      element.classList.toggle("invalid");
    }
  } else {
    if (element.classList.contains("invalid")) {
      element.classList.toggle("invalid");
    }
  }
}
  
export const displayMessage = (element: HTMLElement, message: string): void => {
  const msgcontent: HTMLElement = document.createElement("div");
  msgcontent.id = "msgcontent";
  element.appendChild(msgcontent);
  msgcontent.textContent = message;
}
  
export const removeMessage = (element: HTMLElement): void => {
  if (element.childNodes.length > 0) {
    const noChildren: number = element.childNodes.length
    for (let i = 0; i < noChildren; i++) {
      element.removeChild(element.firstChild);
    }
  }
}