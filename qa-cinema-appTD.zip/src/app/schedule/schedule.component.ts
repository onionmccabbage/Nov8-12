import { Component, OnInit } from '@angular/core';
import { CinemaService } from '../cinema.service';

@Component({
  selector: 'app-schedule',
  templateUrl: './schedule.component.html',
  styleUrls: ['./schedule.component.css']
})
export class ScheduleComponent implements OnInit {

  constructor(private cinemaService:CinemaService) { }
  schedule = [] // careful - no data typing!!!
  ngOnInit(): void {
    // make an initial call to the service and get the schedule
    this.cinemaService.getSchedule()
      .subscribe( (data:any)=>{
        console.log(data) // handy for debugging
        this.schedule = data
      } )
  }

}
