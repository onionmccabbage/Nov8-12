import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { GrayscaleDirective } from './directives/grayscale.directive';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [GrayscaleDirective],
  exports: [GrayscaleDirective]
})
export class SharedModule { }
