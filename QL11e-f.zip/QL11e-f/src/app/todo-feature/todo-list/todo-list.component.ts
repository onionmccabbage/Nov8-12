import { Component, OnInit } from '@angular/core';
import { Todo } from '../todo.model';
// import { TODOS } from '../mock-todos';
import { Observable } from 'rxjs';
import { TodoService } from '../todo.service';
import { ActivatedRoute } from '@angular/router';
import { switchMap } from 'rxjs/operators';

@Component({
  selector: 'app-todo-list',
  templateUrl: './todo-list.component.html',
  styleUrls: ['./todo-list.component.css']
})
export class TodoListComponent implements OnInit {

  // todos: Todo[] = TODOS;
  todo$:Observable<Todo[]>
  selectedId:number

  constructor(private todoService:TodoService,
              private route:ActivatedRoute) { }

  ngOnInit() {
    this.todo$ = this.route.paramMap.pipe(
      switchMap( (params)=>{
        this.selectedId = +params.get('id')
        return this.todoService.getAll()
      } )
    )
  }

}
