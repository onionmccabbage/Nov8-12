import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-my-first',
  templateUrl: './my-first.component.html',
  styleUrls: ['./my-first.component.css']
})
export class MyFirstComponent implements OnInit {

  // declare our model here
  lunch = '12:30'
  tea   = '3:00'

  url = 'https://placekitten.com/120/240'
  w = 120
  h = 240
  count = 0
  // the lab
  public readonly title=`My Data Binding Experiments`;
  public readonly myClasses: string = `red right underlined`;
  public readonly imgUrl: string = `../assets/qalogo.svg`;
  public selected = false;
  public inputtedText = ``;

  constructor() { }

  // here are event call-back handler functions
  doStuff(){
    console.log('button was cliked')
    this.count++ // increment by one
  }


  ngOnInit(): void {
    this.count = 10
  }

}
