import React from 'react';

const SignUp = () => {
    return (
        <p>Sign Up form here</p>
    );
}

export default SignUp;