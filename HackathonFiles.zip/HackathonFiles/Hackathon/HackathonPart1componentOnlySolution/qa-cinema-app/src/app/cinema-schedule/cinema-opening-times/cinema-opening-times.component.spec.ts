import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { CinemaOpeningTimesComponent } from './cinema-opening-times.component';

describe('CinemaOpeningTimesComponent', () => {
  let component: CinemaOpeningTimesComponent;
  let fixture: ComponentFixture<CinemaOpeningTimesComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ CinemaOpeningTimesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CinemaOpeningTimesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
