import React from 'react';
import MyComponent from './MyComponent';

function App() {
  return (
    <MyComponent />
  );
}

export default App;
