let world: string = `World`;
console.log(`Hello ${world}`);