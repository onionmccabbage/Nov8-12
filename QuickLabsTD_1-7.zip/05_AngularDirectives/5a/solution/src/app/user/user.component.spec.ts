import { DebugElement } from '@angular/core';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { By } from '@angular/platform-browser';

import { UserComponent } from './user.component';

describe('UserComponent', () => {
  let component: UserComponent;
  let fixture: ComponentFixture<UserComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ UserComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    const expectedUser = {username: `TestUser`};
    fixture = TestBed.createComponent(UserComponent);
    component = fixture.componentInstance;
    component.user = expectedUser;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it(`should emit a vaule of 1 when upvote is clicked`, () => {
    let voteValue: number;
    const upVoteButton: DebugElement = fixture.debugElement.query(By.css('button#upvote'));
    component.vote.subscribe(value => voteValue = value);
    upVoteButton.triggerEventHandler('click', null);
    expect(voteValue).toBe(1);
  });

  it(`should emit a vaule of -1 when downvote is clicked`, () => {
    let voteValue: number;
    const downVoteButton: DebugElement = fixture.debugElement.query(By.css('button#downvote'));
    component.vote.subscribe(value => voteValue = value);
    downVoteButton.triggerEventHandler('click', null);
    expect(voteValue).toBe(-1);
  });
});
