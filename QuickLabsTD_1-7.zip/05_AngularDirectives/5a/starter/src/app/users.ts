export const users: { username: string, upvotes: number, downvotes: number }[] = [
  {
    username: 'Chris',
    upvotes: 0,
    downvotes: 0
  },
  {
    username: 'Edsel',
    upvotes: 0,
    downvotes: 0
  },
  {
    username: 'Dave',
    upvotes: 0,
    downvotes: 0
  },
  {
    username: 'Ed',
    upvotes: 0,
    downvotes: 0
  },
  {
    username: 'Ada',
    upvotes: 0,
    downvotes: 0
  },
  {
    username: 'Timnit',
    upvotes: 0,
    downvotes: 0
  }
];
