import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cinema-footer',
  templateUrl: './cinema-footer.component.html',
  styleUrls: ['./cinema-footer.component.css']
})
export class CinemaFooterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
