import { Component } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Reactive Forms';
  genders = ['Female', 'Male'];

  // a FormGroup uses an object {} for name:value pairs
  userForm = new FormGroup(
    {firstname : new FormControl(''),
     surname   : new FormControl(''),
     age       : new FormControl(null),
     gender    : new FormControl('')
    }
  )
  // firstname = new FormControl('')
  // surname = new FormControl('')
  // age = new FormControl(null)
  // gender =  new FormControl('')

}
