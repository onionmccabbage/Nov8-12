import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { TodoComponent } from './todo.component';
import { TodoDetailComponent } from './todo-detail/todo-detail.component';
import { TodoHomeComponent } from './todo-home/todo-home.component';
import { TodoListComponent } from './todo-list/todo-list.component';

// declare an array of child routes for this module
const todoRoutes:Routes = [
  {path:'todo', component:TodoComponent, children:[
    {path: "", // added
        component: TodoListComponent, // added (and imported)
        children: [ // added
    // we need an id parameter!!!!
    {path:'tododetails/:id', component:TodoDetailComponent},
    {path:'', component:TodoHomeComponent},
    {path:'**', component:TodoHomeComponent},
  ]}
]} // added
]

@NgModule({
  declarations: [],
  imports: [
    RouterModule.forChild(todoRoutes)
  ],
  exports:[RouterModule]
})
export class TodoFeatureRoutingModule { }
