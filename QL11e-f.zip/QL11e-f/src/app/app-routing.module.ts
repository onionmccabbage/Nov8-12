import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { Page1Component } from './page1/page1.component';
import { Page2Component } from './page2/page2.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';

const routes: Routes = [
  { path: 'page1', component: Page1Component },
  { path: 'page2', component: Page2Component, data: { title: 'Page 2' } },
  { path: '', redirectTo: '/page1', pathMatch: 'full' },
  { path: '**', component: PageNotFoundComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(
    routes,
    { enableTracing: true, relativeLinkResolution: 'legacy' }
    // Note: relativeLinkResolution only included as solution has been upgraded from version 8 of Angular
    // It is not required when working from project built in Angular v11+
  )],
  exports: [RouterModule]
})
export class AppRoutingModule { }
