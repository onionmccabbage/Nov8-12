const colors = require('colors');
console.log("success".green);