import { Component, OnInit } from '@angular/core';

import { User } from '../user.model';
import { UserService } from '../user.service';
import { HttpErrorResponse } from '@angular/common/http';


@Component({
  selector: 'app-list-users',
  templateUrl: './list-users.component.html',
  styleUrls: ['./list-users.component.css']
})
export class ListUsersComponent implements OnInit {

  users: User[];

  public error = false;
  public errorText: string;
  private loading = true;

  constructor(private userService: UserService) { }

  ngOnInit(): void {
    // this.users = this.userService.getUsers();
    this.userService.getUsers().subscribe(
      data => {
        this.users = data;
        this.loading = false;
      },
      (err: HttpErrorResponse) => {
        this.error = true;
        this.loading = false;
        if (!isNaN(err.status)) {
          this.errorText = `${err.status} error: ${err.statusText}`;
        } else if (err instanceof Error) {
          this.errorText = `An error occurred in the application`
        } else {
          this.errorText = `A server error occured`;
        }
      }
    );
  }

}
