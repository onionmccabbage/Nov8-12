export default class User {
    public constructor(
        private title: string, 
        private firstName: string, 
        private lastName: string, 
        private email: string, 
        private phoneNumber: string, 
        private dob: string, 
        private gender: string) {
        
    }
}