export class Instructor {
    firstname: string;
    surname: string;
    courses: string[];
    location: string;
    bio: string;
    src: string;
}
