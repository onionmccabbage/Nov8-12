import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cinema-sign-up',
  templateUrl: './cinema-sign-up.component.html',
  styleUrls: ['./cinema-sign-up.component.css']
})
export class CinemaSignUpComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
