import { Component } from '@angular/core';
import { getLocaleDateFormat } from '@angular/common';
import { TypicodeService } from './typicode.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  // model data goes here
  title = 'people';
  dt_stamp = new Date() // Javascript gives us a date object
  products = [
    {name:'Pot', price:3.99},
    {name:'Dot', price:9.99},
    {name:'Hot', price:1.99}
]
constructor(private typicodeService:TypicodeService){}
// data model for this class
cat = 'users'
id=1
responseData = []
// event handler for the form button
getData(){
  // make a call to the service
  this.typicodeService.getAPI(this.cat, this.id)
    .subscribe( (d:any)=>{
      console.log(d)
      this.responseData = d
    } )
}



}
